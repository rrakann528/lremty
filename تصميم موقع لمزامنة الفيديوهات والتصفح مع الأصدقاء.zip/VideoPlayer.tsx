import { useState } from "react";
import { Socket } from "socket.io-client";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Youtube, Upload } from "lucide-react";
import YouTubePlayer from "./YouTubePlayer";
import LocalVideoPlayer from "./LocalVideoPlayer";

interface VideoPlayerProps {
  socket: Socket | null;
  roomId: string;
  roomIdNum: number;
  isOwner: boolean;
}

export default function VideoPlayer({ socket, roomId, roomIdNum, isOwner }: VideoPlayerProps) {
  const [activeTab, setActiveTab] = useState("youtube");

  return (
    <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
      <TabsList className="w-full justify-start bg-gray-100">
        <TabsTrigger value="youtube" className="flex items-center gap-2">
          <Youtube className="w-4 h-4" />
          YouTube
        </TabsTrigger>
        <TabsTrigger value="local" className="flex items-center gap-2">
          <Upload className="w-4 h-4" />
          فيديو محلي
        </TabsTrigger>
      </TabsList>

      <TabsContent value="youtube" className="mt-4">
        <YouTubePlayer socket={socket} roomId={roomId} isOwner={isOwner} />
      </TabsContent>

      <TabsContent value="local" className="mt-4">
        <LocalVideoPlayer socket={socket} roomId={roomId} roomIdNum={roomIdNum} isOwner={isOwner} />
      </TabsContent>
    </Tabs>
  );
}
