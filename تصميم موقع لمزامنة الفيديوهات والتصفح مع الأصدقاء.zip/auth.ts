import { randomBytes, scryptSync } from "crypto";
import { eq } from "drizzle-orm";
import { users } from "../drizzle/schema";
import { getDb } from "./db";

const SALT_LENGTH = 16;
const SCRYPT_PARAMS = {
  N: 16384,
  r: 8,
  p: 1,
  maxmem: 64 * 1024 * 1024,
};

/**
 * Hash a password using scrypt
 */
export function hashPassword(password: string): string {
  const salt = randomBytes(SALT_LENGTH).toString("hex");
  const hash = scryptSync(password, salt, 64, SCRYPT_PARAMS).toString("hex");
  return `${salt}:${hash}`;
}

/**
 * Verify a password against a hash
 */
export function verifyPassword(password: string, hash: string): boolean {
  const [salt, storedHash] = hash.split(":");
  if (!salt || !storedHash) return false;

  const computedHash = scryptSync(password, salt, 64, SCRYPT_PARAMS).toString("hex");
  return computedHash === storedHash;
}

/**
 * Register a new user
 */
export async function registerUser(
  username: string,
  email: string,
  password: string,
  name?: string
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  // Check if user already exists
  const existing = await db
    .select()
    .from(users)
    .where(eq(users.username, username))
    .limit(1);

  if (existing.length > 0) {
    throw new Error("Username already exists");
  }

  // Check if email already exists
  const existingEmail = await db
    .select()
    .from(users)
    .where(eq(users.email, email))
    .limit(1);

  if (existingEmail.length > 0) {
    throw new Error("Email already exists");
  }

  // Hash password
  const passwordHash = hashPassword(password);

  // Create user
  const result = await db.insert(users).values({
    username,
    email,
    passwordHash,
    name: name || username,
    role: "user",
  });

  // Get the created user
  const newUser = await db
    .select()
    .from(users)
    .where(eq(users.username, username))
    .limit(1);

  return newUser[0];
}

/**
 * Login user
 */
export async function loginUser(username: string, password: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const user = await db
    .select()
    .from(users)
    .where(eq(users.username, username))
    .limit(1);

  if (user.length === 0) {
    throw new Error("Invalid username or password");
  }

  const foundUser = user[0];

  // Verify password
  if (!verifyPassword(password, foundUser.passwordHash)) {
    throw new Error("Invalid username or password");
  }

  // Update last signed in
  await db
    .update(users)
    .set({ lastSignedIn: new Date() })
    .where(eq(users.id, foundUser.id));

  return foundUser;
}

/**
 * Get user by ID
 */
export async function getUserById(id: number) {
  const db = await getDb();
  if (!db) return null;

  const user = await db
    .select()
    .from(users)
    .where(eq(users.id, id))
    .limit(1);

  return user[0] || null;
}

/**
 * Get user by username
 */
export async function getUserByUsername(username: string) {
  const db = await getDb();
  if (!db) return null;

  const user = await db
    .select()
    .from(users)
    .where(eq(users.username, username))
    .limit(1);

  return user[0] || null;
}
