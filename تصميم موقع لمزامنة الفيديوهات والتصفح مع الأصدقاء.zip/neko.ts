import { spawn } from "child_process";
import { v4 as uuidv4 } from "uuid";

interface NekoInstance {
  roomId: string;
  containerId: string;
  port: number;
  wsPort: number;
  password: string;
  createdAt: Date;
  lastActivity: Date;
  url: string;
}

const nekoInstances = new Map<string, NekoInstance>();
const basePort = 8080;
const baseWsPort = 9000;
let portCounter = 0;

// Check if Docker is available
let dockerAvailable = false;

async function checkDockerAvailability(): Promise<boolean> {
  return new Promise((resolve) => {
    const docker = spawn("docker", ["--version"]);
    docker.on("close", (code) => {
      resolve(code === 0);
    });
    docker.on("error", () => {
      resolve(false);
    });
  });
}

// Initialize Docker check
checkDockerAvailability().then((available) => {
  dockerAvailable = available;
  if (dockerAvailable) {
    console.log("[Neko] Docker is available");
  } else {
    console.warn("[Neko] Docker is not available - Neko features will be disabled");
  }
});

/**
 * Start a new Neko instance for a room
 */
export async function startNekoInstance(roomId: string): Promise<NekoInstance | null> {
  try {
    if (!dockerAvailable) {
      console.error("[Neko] Docker is not available");
      throw new Error("Docker غير متوفر على الخادم");
    }

    // Check if instance already exists
    if (nekoInstances.has(roomId)) {
      const instance = nekoInstances.get(roomId)!;
      instance.lastActivity = new Date();
      return instance;
    }

    const port = basePort + portCounter;
    const wsPort = baseWsPort + portCounter;
    portCounter++;

    const password = uuidv4().substring(0, 8);
    const containerId = `neko-${roomId}-${Date.now()}`;
    const url = `http://localhost:${port}`;

    // Docker command to start Neko container
    const dockerArgs = [
      "run",
      "-d",
      "--name",
      containerId,
      "-p",
      `${port}:8080`,
      "-p",
      `${wsPort}:9000`,
      "-e",
      `NEKO_PASSWORD=${password}`,
      "-e",
      "NEKO_SCREEN=1920x1080",
      "-e",
      "NEKO_AUDIO=true",
      "-e",
      "NEKO_AUDIO_CODEC=opus",
      "--rm",
      "m1k1o/neko:latest",
    ];

    return new Promise((resolve) => {
      let errorOutput = "";
      const docker = spawn("docker", dockerArgs);

      docker.stderr.on("data", (data) => {
        errorOutput += data.toString();
      });

      docker.on("close", (code) => {
        if (code === 0) {
          const instance: NekoInstance = {
            roomId,
            containerId,
            port,
            wsPort,
            password,
            url,
            createdAt: new Date(),
            lastActivity: new Date(),
          };

          nekoInstances.set(roomId, instance);
          console.log(`[Neko] Started instance for room ${roomId} on port ${port}`);
          resolve(instance);
        } else {
          console.error(`[Neko] Failed to start container: ${errorOutput}`);
          resolve(null);
        }
      });

      docker.on("error", (error) => {
        console.error(`[Neko] Error starting container: ${error.message}`);
        resolve(null);
      });

      // Timeout after 30 seconds
      setTimeout(() => {
        if (!nekoInstances.has(roomId)) {
          docker.kill();
          console.error("[Neko] Container startup timeout");
          resolve(null);
        }
      }, 30000);
    });
  } catch (error: any) {
    console.error("[Neko] Error:", error.message);
    throw error;
  }
}

/**
 * Stop a Neko instance
 */
export async function stopNekoInstance(roomId: string): Promise<boolean> {
  try {
    const instance = nekoInstances.get(roomId);
    if (!instance) {
      return false;
    }

    return new Promise((resolve) => {
      const docker = spawn("docker", ["stop", instance.containerId]);

      docker.on("close", (code) => {
        if (code === 0) {
          nekoInstances.delete(roomId);
          console.log(`[Neko] Stopped instance for room ${roomId}`);
          resolve(true);
        } else {
          console.error(`[Neko] Failed to stop container for room ${roomId}`);
          resolve(false);
        }
      });

      docker.on("error", (error) => {
        console.error(`[Neko] Error stopping container: ${error.message}`);
        resolve(false);
      });
    });
  } catch (error) {
    console.error("[Neko] Error:", error);
    return false;
  }
}

/**
 * Get Neko instance details
 */
export function getNekoInstance(roomId: string): NekoInstance | null {
  const instance = nekoInstances.get(roomId);
  if (instance) {
    instance.lastActivity = new Date();
    return instance;
  }
  return null;
}

/**
 * Get all active Neko instances
 */
export function getAllNekoInstances(): NekoInstance[] {
  const instances: NekoInstance[] = [];
  nekoInstances.forEach((instance) => {
    instances.push(instance);
  });
  return instances;
}

/**
 * Check if Docker is available
 */
export function isDockerAvailable(): boolean {
  return dockerAvailable;
}

/**
 * Cleanup inactive instances (older than 1 hour)
 */
export async function cleanupInactiveInstances(): Promise<void> {
  const now = new Date();
  const maxInactiveTime = 60 * 60 * 1000; // 1 hour
  const roomsToCleanup: string[] = [];

  nekoInstances.forEach((instance, roomId) => {
    const inactiveTime = now.getTime() - instance.lastActivity.getTime();
    if (inactiveTime > maxInactiveTime) {
      roomsToCleanup.push(roomId);
    }
  });

  for (const roomId of roomsToCleanup) {
    console.log(`[Neko] Cleaning up inactive instance for room ${roomId}`);
    await stopNekoInstance(roomId);
  }
}

// Cleanup every 10 minutes
setInterval(cleanupInactiveInstances, 10 * 60 * 1000);
