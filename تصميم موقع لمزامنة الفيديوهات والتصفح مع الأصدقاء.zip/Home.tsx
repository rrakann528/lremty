import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

import { trpc } from "@/lib/trpc";
import { Video, Users, MessageSquare, Globe } from "lucide-react";
import { useState } from "react";
import { useLocation } from "wouter";
import { toast } from "sonner";

export default function Home() {
  const { user, isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();
  const [roomName, setRoomName] = useState("");
  const [joinRoomId, setJoinRoomId] = useState("");

  const createRoomMutation = trpc.rooms.create.useMutation({
    onSuccess: (room) => {
      if (room) {
        toast.success("تم إنشاء الغرفة بنجاح!");
        setLocation(`/room/${room.uuid}`);
      }
    },
    onError: (error) => {
      toast.error("فشل إنشاء الغرفة: " + error.message);
    },
  });

  const handleCreateRoom = () => {
    if (!roomName.trim()) {
      toast.error("يرجى إدخال اسم الغرفة");
      return;
    }
    createRoomMutation.mutate({ name: roomName });
  };

  const handleJoinRoom = () => {
    if (!joinRoomId.trim()) {
      toast.error("يرجى إدخال معرف الغرفة");
      return;
    }
    setLocation(`/room/${joinRoomId}`);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-blue-50 to-pink-50">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <Video className="w-8 h-8 text-purple-600" />
            <h1 className="text-2xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
              SyncWatch
            </h1>
          </div>
          <div>
            {isAuthenticated ? (
              <div className="flex items-center gap-4">
                <span className="text-sm text-gray-600">مرحباً، {user?.name}</span>
              </div>
            ) : (
              <Button asChild>
                <a href="/auth">تسجيل الدخول</a>
              </Button>
            )}
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="container mx-auto px-4 py-16 text-center">
        <h2 className="text-5xl font-bold mb-6 bg-gradient-to-r from-purple-600 via-blue-600 to-pink-600 bg-clip-text text-transparent">
          شاهد وتصفح مع أصدقائك
        </h2>
        <p className="text-xl text-gray-600 mb-12 max-w-2xl mx-auto">
          منصة متكاملة لمشاهدة الفيديوهات والتصفح المشترك مع الأصدقاء في الوقت الفعلي، مع دردشة نصية وصوتية
        </p>

        {/* Features Grid */}
        <div className="grid md:grid-cols-4 gap-6 mb-16">
          <Card className="border-purple-200 hover:shadow-lg transition-shadow">
            <CardHeader>
              <Video className="w-12 h-12 text-purple-600 mx-auto mb-2" />
              <CardTitle className="text-lg">مزامنة الفيديو</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-600">
                شاهد YouTube والفيديوهات المحلية بشكل متزامن مع الجميع
              </p>
            </CardContent>
          </Card>

          <Card className="border-blue-200 hover:shadow-lg transition-shadow">
            <CardHeader>
              <Globe className="w-12 h-12 text-blue-600 mx-auto mb-2" />
              <CardTitle className="text-lg">متصفح مشترك</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-600">
                تصفح الإنترنت معاً في متصفح افتراضي متزامن
              </p>
            </CardContent>
          </Card>

          <Card className="border-pink-200 hover:shadow-lg transition-shadow">
            <CardHeader>
              <MessageSquare className="w-12 h-12 text-pink-600 mx-auto mb-2" />
              <CardTitle className="text-lg">دردشة فورية</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-600">
                تواصل مع أصدقائك عبر الدردشة النصية والصوتية
              </p>
            </CardContent>
          </Card>

          <Card className="border-green-200 hover:shadow-lg transition-shadow">
            <CardHeader>
              <Users className="w-12 h-12 text-green-600 mx-auto mb-2" />
              <CardTitle className="text-lg">غرف متعددة</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-600">
                أنشئ غرفاً خاصة وادعُ أصدقاءك للانضمام
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Action Cards */}
        {isAuthenticated ? (
          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            <Card className="border-2 border-purple-200 hover:border-purple-400 transition-colors">
              <CardHeader>
                <CardTitle className="text-2xl">إنشاء غرفة جديدة</CardTitle>
                <CardDescription>ابدأ جلسة مشاهدة جديدة مع أصدقائك</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="room-name">اسم الغرفة</Label>
                  <Input
                    id="room-name"
                    placeholder="أدخل اسم الغرفة"
                    value={roomName}
                    onChange={(e) => setRoomName(e.target.value)}
                    onKeyDown={(e) => e.key === "Enter" && handleCreateRoom()}
                  />
                </div>
                <Button
                  className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
                  onClick={handleCreateRoom}
                  disabled={createRoomMutation.isPending}
                >
                  {createRoomMutation.isPending ? "جاري الإنشاء..." : "إنشاء غرفة"}
                </Button>
              </CardContent>
            </Card>

            <Card className="border-2 border-blue-200 hover:border-blue-400 transition-colors">
              <CardHeader>
                <CardTitle className="text-2xl">الانضمام لغرفة</CardTitle>
                <CardDescription>انضم إلى غرفة موجودة باستخدام المعرف</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="join-room-id">معرف الغرفة</Label>
                  <Input
                    id="join-room-id"
                    placeholder="أدخل معرف الغرفة"
                    value={joinRoomId}
                    onChange={(e) => setJoinRoomId(e.target.value)}
                    onKeyDown={(e) => e.key === "Enter" && handleJoinRoom()}
                  />
                </div>
                <Button
                  className="w-full bg-gradient-to-r from-blue-600 to-pink-600 hover:from-blue-700 hover:to-pink-700"
                  onClick={handleJoinRoom}
                >
                  الانضمام
                </Button>
              </CardContent>
            </Card>
          </div>
        ) : (
          <Card className="max-w-md mx-auto border-2 border-purple-200">
            <CardHeader>
              <CardTitle className="text-2xl">ابدأ الآن</CardTitle>
              <CardDescription>سجل الدخول للبدء في استخدام المنصة</CardDescription>
            </CardHeader>
            <CardContent>
              <Button asChild className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700">
                <a href="/auth">تسجيل الدخول</a>
              </Button>
            </CardContent>
          </Card>
        )}
      </section>

      {/* Footer */}
      <footer className="border-t bg-white/80 backdrop-blur-sm mt-16">
        <div className="container mx-auto px-4 py-8 text-center text-gray-600">
          <p>© 2025 SyncWatch. جميع الحقوق محفوظة.</p>
        </div>
      </footer>
    </div>
  );
}
