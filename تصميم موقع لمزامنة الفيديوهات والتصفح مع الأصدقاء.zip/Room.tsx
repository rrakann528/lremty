import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { trpc } from "@/lib/trpc";
import { Video, Globe, Users, MessageSquare, Mic, MicOff, Copy, Check } from "lucide-react";
import { useEffect, useState } from "react";
import { useLocation, useRoute } from "wouter";
import { toast } from "sonner";
import { io, Socket } from "socket.io-client";
import { getLoginUrl } from "@/const";
import VideoPlayer from "@/components/VideoPlayer";
import ChatBox from "@/components/ChatBox";
import NekoViewer from "@/components/NekoViewer";

interface RoomUser {
  id: string;
  userId: number;
  userName: string;
}

export default function Room() {
  const [, params] = useRoute("/room/:uuid");
  const [, setLocation] = useLocation();
  const { user, isAuthenticated } = useAuth();
  const [socket, setSocket] = useState<Socket | null>(null);
  const [roomUsers, setRoomUsers] = useState<RoomUser[]>([]);
  const [copied, setCopied] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [activeTab, setActiveTab] = useState("video");

  const roomUuid = params?.uuid || "";

  const { data: room, isLoading } = trpc.rooms.getByUuid.useQuery(
    { uuid: roomUuid },
    { enabled: !!roomUuid }
  );

  const isOwner = room && user ? room.ownerId === user.id : false;

  useEffect(() => {
    if (!isAuthenticated) {
      return;
    }

    if (!room || !user) return;

    // Connect to Socket.IO
    const newSocket = io({
      path: '/api/socket.io',
    });

    newSocket.on('connect', () => {
      console.log('Connected to Socket.IO');
      newSocket.emit('join-room', {
        roomId: roomUuid,
        userId: user.id,
        userName: user.name || 'مستخدم',
      });
    });

    newSocket.on('join-success', ({ users }: { users: RoomUser[] }) => {
      setRoomUsers(users);
      toast.success('تم الانضمام إلى الغرفة');
    });

    newSocket.on('room-users', (users: RoomUser[]) => {
      setRoomUsers(users);
    });

    newSocket.on('disconnect', () => {
      console.log('Disconnected from Socket.IO');
    });

    setSocket(newSocket);

    return () => {
      newSocket.emit('leave-room', { roomId: roomUuid });
      newSocket.close();
    };
  }, [room, user, roomUuid, isAuthenticated]);

  const copyRoomLink = () => {
    const link = `${window.location.origin}/room/${roomUuid}`;
    navigator.clipboard.writeText(link);
    setCopied(true);
    toast.success('تم نسخ رابط الغرفة');
    setTimeout(() => setCopied(false), 2000);
  };

  const toggleMute = () => {
    setIsMuted(!isMuted);
    toast.info(isMuted ? 'تم إلغاء كتم الصوت' : 'تم كتم الصوت');
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-purple-50 via-blue-50 to-pink-50">
        <Card className="p-8 max-w-md text-center">
          <h2 className="text-2xl font-bold mb-4">يجب تسجيل الدخول</h2>