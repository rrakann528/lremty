import { describe, it, expect } from "vitest";
import { hashPassword, verifyPassword, registerUser, loginUser } from "./auth";

describe("Password Hashing", () => {
  it("should hash a password", () => {
    const password = "testPassword123";
    const hash = hashPassword(password);

    expect(hash).toBeDefined();
    expect(hash).toContain(":");
    expect(hash.split(":")).toHaveLength(2);
  });

  it("should verify a correct password", () => {
    const password = "testPassword123";
    const hash = hashPassword(password);

    const isValid = verifyPassword(password, hash);
    expect(isValid).toBe(true);
  });

  it("should reject an incorrect password", () => {
    const password = "testPassword123";
    const wrongPassword = "wrongPassword456";
    const hash = hashPassword(password);

    const isValid = verifyPassword(wrongPassword, hash);
    expect(isValid).toBe(false);
  });

  it("should produce different hashes for the same password", () => {
    const password = "testPassword123";
    const hash1 = hashPassword(password);
    const hash2 = hashPassword(password);

    expect(hash1).not.toBe(hash2);
    expect(verifyPassword(password, hash1)).toBe(true);
    expect(verifyPassword(password, hash2)).toBe(true);
  });
});

describe("User Registration", () => {
  it("should register a new user", async () => {
    const user = await registerUser(
      `testuser_${Date.now()}`,
      `test_${Date.now()}@example.com`,
      "testPassword123",
      "Test User"
    );

    expect(user).toBeDefined();
    expect(user.username).toBeDefined();
    expect(user.email).toBeDefined();
    expect(user.name).toBe("Test User");
    expect(user.role).toBe("user");
  });

  it("should reject duplicate username", async () => {
    const username = `testuser_${Date.now()}`;
    const email1 = `test1_${Date.now()}@example.com`;
    const email2 = `test2_${Date.now()}@example.com`;

    await registerUser(username, email1, "password123");

    try {
      await registerUser(username, email2, "password123");
      expect.fail("Should have thrown an error");
    } catch (error: any) {
      expect(error.message).toContain("already exists");
    }
  });

  it("should reject duplicate email", async () => {
    const username1 = `testuser1_${Date.now()}`;
    const username2 = `testuser2_${Date.now()}`;
    const email = `test_${Date.now()}@example.com`;

    await registerUser(username1, email, "password123");

    try {
      await registerUser(username2, email, "password123");
      expect.fail("Should have thrown an error");
    } catch (error: any) {
      expect(error.message).toContain("already exists");
    }
  });
});

describe("User Login", () => {
  it("should login a registered user", async () => {
    const username = `testuser_${Date.now()}`;
    const email = `test_${Date.now()}@example.com`;
    const password = "testPassword123";

    await registerUser(username, email, password, "Test User");

    const user = await loginUser(username, password);

    expect(user).toBeDefined();
    expect(user.username).toBe(username);
    expect(user.email).toBe(email);
  });

  it("should reject login with wrong password", async () => {
    const username = `testuser_${Date.now()}`;
    const email = `test_${Date.now()}@example.com`;
    const password = "testPassword123";

    await registerUser(username, email, password);

    try {
      await loginUser(username, "wrongPassword");
      expect.fail("Should have thrown an error");
    } catch (error: any) {
      expect(error.message).toContain("Invalid");
    }
  });

  it("should reject login with non-existent user", async () => {
    try {
      await loginUser("nonexistent_user", "password123");
      expect.fail("Should have thrown an error");
    } catch (error: any) {
      expect(error.message).toContain("Invalid");
    }
  });

  it("should update lastSignedIn on login", async () => {
    const username = `testuser_${Date.now()}`;
    const email = `test_${Date.now()}@example.com`;
    const password = "testPassword123";

    const registered = await registerUser(username, email, password);
    const beforeLogin = registered.lastSignedIn;

    // Wait a bit to ensure time difference
    await new Promise(resolve => setTimeout(resolve, 100));

    const loggedIn = await loginUser(username, password);
    const afterLogin = loggedIn.lastSignedIn;

    expect(afterLogin.getTime()).toBeGreaterThanOrEqual(beforeLogin.getTime());
  });
});
