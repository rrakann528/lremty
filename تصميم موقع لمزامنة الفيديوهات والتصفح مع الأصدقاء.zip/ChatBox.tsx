import { useEffect, useRef, useState } from "react";
import { Socket } from "socket.io-client";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { ScrollArea } from "./ui/scroll-area";
import { Send } from "lucide-react";
import { toast } from "sonner";

interface Message {
  userId: number;
  userName: string;
  content: string;
  createdAt: Date;
}

interface ChatBoxProps {
  socket: Socket | null;
  roomId: string;
  roomIdNum: number;
  userId: number;
  userName: string;
}

export default function ChatBox({ socket, roomId, roomIdNum, userId, userName }: ChatBoxProps) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputMessage, setInputMessage] = useState("");
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!socket) return;

    socket.on("new-message", (message: Message) => {
      setMessages((prev) => [...prev, { ...message, createdAt: new Date(message.createdAt) }]);
    });

    return () => {
      socket.off("new-message");
    };
  }, [socket]);

  useEffect(() => {
    // Auto-scroll to bottom when new messages arrive
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const sendMessage = () => {
    if (!inputMessage.trim()) {
      return;
    }

    if (!socket) {
      toast.error("غير متصل بالخادم");
      return;
    }

    socket.emit("send-message", {
      roomId,
      roomIdNum,
      userId,
      userName,
      content: inputMessage.trim(),
    });

    setInputMessage("");
  };

  const formatTime = (date: Date) => {
    return new Intl.DateTimeFormat("ar", {
      hour: "2-digit",
      minute: "2-digit",
    }).format(date);
  };

  return (
    <div className="flex flex-col h-full">
      {/* Messages */}
      <ScrollArea className="flex-1 p-4" ref={scrollRef}>
        <div className="space-y-3">
          {messages.length === 0 ? (
            <div className="text-center text-gray-400 text-sm py-8">
              لا توجد رسائل بعد. ابدأ المحادثة!
            </div>
          ) : (
            messages.map((message, index) => (
              <div
                key={index}
                className={`flex flex-col ${
                  message.userId === userId ? "items-end" : "items-start"
                }`}
              >
                <div
                  className={`max-w-[80%] rounded-lg px-3 py-2 ${
                    message.userId === userId
                      ? "bg-purple-600 text-white"
                      : "bg-gray-100 text-gray-800"
                  }`}
                >
                  {message.userId !== userId && (
                    <p className="text-xs font-semibold mb-1 opacity-80">
                      {message.userName}
                    </p>
                  )}
                  <p className="text-sm break-words">{message.content}</p>
                </div>
                <span className="text-xs text-gray-400 mt-1">
                  {formatTime(message.createdAt)}
                </span>
              </div>
            ))
          )}
        </div>
      </ScrollArea>

      {/* Input */}
      <div className="border-t p-3 bg-white">
        <div className="flex gap-2">
          <Input
            placeholder="اكتب رسالة..."
            value={inputMessage}
            onChange={(e) => setInputMessage(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && sendMessage()}
            className="flex-1"
          />
          <Button
            onClick={sendMessage}
            disabled={!inputMessage.trim()}
            size="icon"
            className="shrink-0"
          >
            <Send className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}
