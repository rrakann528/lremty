import { useEffect, useRef, useState } from "react";
import { Socket } from "socket.io-client";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Play, Pause, SkipForward, SkipBack, Upload } from "lucide-react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";

interface LocalVideoPlayerProps {
  socket: Socket | null;
  roomId: string;
  roomIdNum: number;
  isOwner: boolean;
}

export default function LocalVideoPlayer({ socket, roomId, roomIdNum, isOwner }: LocalVideoPlayerProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [videoUrl, setVideoUrl] = useState<string>("");
  const [isPlaying, setIsPlaying] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const isSyncing = useRef(false);

  const uploadVideoMutation = trpc.videos.upload.useMutation();

  // Socket event listeners
  useEffect(() => {
    if (!socket || !videoRef.current) return;

    socket.on("video-load", ({ type, videoUrl: newVideoUrl }: { type: string; videoUrl: string }) => {
      if (type === "local" && newVideoUrl && videoRef.current) {
        isSyncing.current = true;
        videoRef.current.src = newVideoUrl;
        videoRef.current.load();
        setVideoUrl(newVideoUrl);
        setTimeout(() => {
          isSyncing.current = false;
        }, 500);
      }
    });

    socket.on("video-play", ({ currentTime }: { currentTime: number }) => {
      if (videoRef.current) {
        isSyncing.current = true;
        videoRef.current.currentTime = currentTime;
        videoRef.current.play().catch(console.error);
        setIsPlaying(true);
        setTimeout(() => {
          isSyncing.current = false;
        }, 500);
      }
    });

    socket.on("video-pause", ({ currentTime }: { currentTime: number }) => {
      if (videoRef.current) {
        isSyncing.current = true;
        videoRef.current.currentTime = currentTime;
        videoRef.current.pause();
        setIsPlaying(false);
        setTimeout(() => {
          isSyncing.current = false;
        }, 500);
      }
    });

    socket.on("video-seek", ({ currentTime }: { currentTime: number }) => {
      if (videoRef.current) {
        isSyncing.current = true;
        videoRef.current.currentTime = currentTime;
        setTimeout(() => {
          isSyncing.current = false;
        }, 500);
      }
    });

    socket.on("video-state", (state: any) => {
      if (state.type === "local" && state.videoUrl && videoRef.current) {
        isSyncing.current = true;
        videoRef.current.src = state.videoUrl;
        videoRef.current.currentTime = state.currentTime;
        if (state.isPlaying) {
          videoRef.current.play().catch(console.error);
        } else {
          videoRef.current.pause();
        }
        setVideoUrl(state.videoUrl);
        setIsPlaying(state.isPlaying);
        setTimeout(() => {
          isSyncing.current = false;
        }, 500);
      }
    });

    return () => {
      socket.off("video-load");
      socket.off("video-play");
      socket.off("video-pause");
      socket.off("video-seek");
      socket.off("video-state");
    };
  }, [socket]);

  // Video event handlers
  const handleVideoPlay = () => {
    if (isSyncing.current || !isOwner) return;
    const time = videoRef.current?.currentTime || 0;
    socket?.emit("video-play", { roomId, currentTime: time });
    setIsPlaying(true);
  };

  const handleVideoPause = () => {
    if (isSyncing.current || !isOwner) return;
    const time = videoRef.current?.currentTime || 0;
    socket?.emit("video-pause", { roomId, currentTime: time });
    setIsPlaying(false);
  };

  const handleVideoSeeking = () => {
    if (isSyncing.current || !isOwner) return;
    const time = videoRef.current?.currentTime || 0;
    socket?.emit("video-seek", { roomId, currentTime: time });
  };

  const handleFileSelect = async (event: React.ChangeEvent<HTMLInputElement>) => {
    if (!isOwner) {
      toast.error("فقط مالك الغرفة يمكنه رفع فيديو");
      return;
    }

    const file = event.target.files?.[0];
    if (!file) return;

    // Check file type
    if (!file.type.startsWith("video/")) {
      toast.error("يرجى اختيار ملف فيديو");
      return;
    }

    // Check file size (max 50MB)
    const maxSize = 50 * 1024 * 1024;
    if (file.size > maxSize) {
      toast.error("حجم الملف كبير جداً. الحد الأقصى 50 ميجابايت");
      return;
    }

    setIsUploading(true);
    toast.info("جاري رفع الفيديو...");

    try {
      // Read file as base64
      const reader = new FileReader();
      reader.onload = async (e) => {
        const base64 = e.target?.result as string;
        const base64Data = base64.split(",")[1]; // Remove data:video/...;base64, prefix

        try {
          const result = await uploadVideoMutation.mutateAsync({
            roomId: roomIdNum,
            fileName: file.name,
            fileData: base64Data,
            mimeType: file.type,
          });

          // Load video for all users
          if (videoRef.current) {
            videoRef.current.src = result.url;
            videoRef.current.load();
          }
          setVideoUrl(result.url);

          socket?.emit("video-load", {
            roomId,
            type: "local",
            videoUrl: result.url,
          });

          toast.success("تم رفع الفيديو بنجاح");
        } catch (error: any) {
          toast.error("فشل رفع الفيديو: " + error.message);
        } finally {
          setIsUploading(false);
        }
      };

      reader.onerror = () => {
        toast.error("فشل قراءة الملف");
        setIsUploading(false);
      };

      reader.readAsDataURL(file);
    } catch (error: any) {
      toast.error("حدث خطأ: " + error.message);
      setIsUploading(false);
    }
  };

  const handlePlayPause = () => {
    if (!isOwner) {
      toast.error("فقط مالك الغرفة يمكنه التحكم");
      return;
    }

    if (!videoUrl) {
      toast.error("يرجى رفع فيديو أولاً");
      return;
    }

    if (isPlaying) {
      videoRef.current?.pause();
    } else {
      videoRef.current?.play();
    }
  };

  const handleSeek = (seconds: number) => {
    if (!isOwner) {
      toast.error("فقط مالك الغرفة يمكنه التحكم");
      return;
    }

    if (!videoRef.current) return;

    const newTime = Math.max(0, videoRef.current.currentTime + seconds);
    videoRef.current.currentTime = newTime;
    socket?.emit("video-seek", { roomId, currentTime: newTime });
  };

  return (
    <div className="space-y-4">
      {/* Upload Button */}
      {isOwner && (
        <div>
          <input
            ref={fileInputRef}
            type="file"
            accept="video/*"
            onChange={handleFileSelect}
            className="hidden"
          />
          <Button
            onClick={() => fileInputRef.current?.click()}
            disabled={isUploading}
            className="w-full flex items-center justify-center gap-2"
          >
            <Upload className="w-4 h-4" />
            {isUploading ? "جاري الرفع..." : "رفع فيديو محلي"}
          </Button>
        </div>
      )}

      {/* Video Player */}
      <div className="aspect-video bg-black rounded-lg overflow-hidden">
        {videoUrl ? (
          <video
            ref={videoRef}
            className="w-full h-full"
            onPlay={handleVideoPlay}
            onPause={handleVideoPause}
            onSeeking={handleVideoSeeking}
            controls={false}
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-white">
            <div className="text-center">
              <Upload className="w-16 h-16 mx-auto mb-4 opacity-50" />
              <p className="text-lg">لم يتم رفع فيديو بعد</p>
              {isOwner && <p className="text-sm opacity-75 mt-2">انقر على "رفع فيديو محلي" للبدء</p>}
            </div>
          </div>
        )}
      </div>

      {/* Controls */}
      <div className="flex items-center justify-center gap-2">
        <Button
          variant="outline"
          size="icon"
          onClick={() => handleSeek(-10)}
          disabled={!isOwner || !videoUrl}
        >
          <SkipBack className="w-4 h-4" />
        </Button>

        <Button
          size="icon"
          onClick={handlePlayPause}
          disabled={!isOwner || !videoUrl}
          className="w-12 h-12"
        >
          {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5" />}
        </Button>

        <Button
          variant="outline"
          size="icon"
          onClick={() => handleSeek(10)}
          disabled={!isOwner || !videoUrl}
        >
          <SkipForward className="w-4 h-4" />
        </Button>
      </div>

      {!isOwner && (
        <p className="text-sm text-center text-gray-500">
          فقط مالك الغرفة يمكنه التحكم في الفيديو
        </p>
      )}
    </div>
  );
}
