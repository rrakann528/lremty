import { useEffect, useRef, useState } from "react";
import { Socket } from "socket.io-client";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Play, Pause, SkipForward, SkipBack, Search } from "lucide-react";
import { toast } from "sonner";

interface YouTubePlayerProps {
  socket: Socket | null;
  roomId: string;
  isOwner: boolean;
}

// Declare YouTube API types
declare global {
  interface Window {
    YT: any;
    onYouTubeIframeAPIReady: () => void;
  }
}

export default function YouTubePlayer({ socket, roomId, isOwner }: YouTubePlayerProps) {
  const playerRef = useRef<any>(null);
  const [isReady, setIsReady] = useState(false);
  const [videoId, setVideoId] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const isSyncing = useRef(false);

  // Load YouTube IFrame API
  useEffect(() => {
    if (!window.YT) {
      const tag = document.createElement("script");
      tag.src = "https://www.youtube.com/iframe_api";
      const firstScriptTag = document.getElementsByTagName("script")[0];
      firstScriptTag.parentNode?.insertBefore(tag, firstScriptTag);

      window.onYouTubeIframeAPIReady = () => {
        initializePlayer();
      };
    } else {
      initializePlayer();
    }
  }, []);

  const initializePlayer = () => {
    playerRef.current = new window.YT.Player("youtube-player", {
      height: "100%",
      width: "100%",
      videoId: "",
      playerVars: {
        controls: 0,
        modestbranding: 1,
        rel: 0,
      },
      events: {
        onReady: onPlayerReady,
        onStateChange: onPlayerStateChange,
      },
    });
  };

  const onPlayerReady = () => {
    setIsReady(true);
    console.log("YouTube player ready");
  };

  const onPlayerStateChange = (event: any) => {
    if (isSyncing.current) return;

    const state = event.data;
    const time = playerRef.current?.getCurrentTime() || 0;

    // YT.PlayerState.PLAYING = 1, PAUSED = 2
    if (state === 1 && isOwner) {
      socket?.emit("video-play", { roomId, currentTime: time });
      setIsPlaying(true);
    } else if (state === 2 && isOwner) {
      socket?.emit("video-pause", { roomId, currentTime: time });
      setIsPlaying(false);
    }
  };

  // Socket event listeners
  useEffect(() => {
    if (!socket || !playerRef.current) return;

    socket.on("video-load", ({ type, videoId: newVideoId }: { type: string; videoId: string }) => {
      if (type === "youtube" && newVideoId) {
        isSyncing.current = true;
        playerRef.current?.loadVideoById(newVideoId);
        setVideoId(newVideoId);
        setTimeout(() => {
          isSyncing.current = false;
        }, 500);
      }
    });

    socket.on("video-play", ({ currentTime: time }: { currentTime: number }) => {
      isSyncing.current = true;
      playerRef.current?.seekTo(time, true);
      playerRef.current?.playVideo();
      setIsPlaying(true);
      setCurrentTime(time);
      setTimeout(() => {
        isSyncing.current = false;
      }, 500);
    });

    socket.on("video-pause", ({ currentTime: time }: { currentTime: number }) => {
      isSyncing.current = true;
      playerRef.current?.seekTo(time, true);
      playerRef.current?.pauseVideo();
      setIsPlaying(false);
      setCurrentTime(time);
      setTimeout(() => {
        isSyncing.current = false;
      }, 500);
    });

    socket.on("video-seek", ({ currentTime: time }: { currentTime: number }) => {
      isSyncing.current = true;
      playerRef.current?.seekTo(time, true);
      setCurrentTime(time);
      setTimeout(() => {
        isSyncing.current = false;
      }, 500);
    });

    socket.on("video-state", (state: any) => {
      if (state.type === "youtube" && state.videoId) {
        isSyncing.current = true;
        playerRef.current?.loadVideoById(state.videoId);
        playerRef.current?.seekTo(state.currentTime, true);
        if (state.isPlaying) {
          playerRef.current?.playVideo();
        } else {
          playerRef.current?.pauseVideo();
        }
        setVideoId(state.videoId);
        setIsPlaying(state.isPlaying);
        setCurrentTime(state.currentTime);
        setTimeout(() => {
          isSyncing.current = false;
        }, 500);
      }
    });

    return () => {
      socket.off("video-load");
      socket.off("video-play");
      socket.off("video-pause");
      socket.off("video-seek");
      socket.off("video-state");
    };
  }, [socket]);

  const extractVideoId = (url: string): string | null => {
    const patterns = [
      /(?:youtube\.com\/watch\?v=|youtu\.be\/)([a-zA-Z0-9_-]{11})/,
      /^([a-zA-Z0-9_-]{11})$/,
    ];

    for (const pattern of patterns) {
      const match = url.match(pattern);
      if (match) return match[1];
    }
    return null;
  };

  const handleLoadVideo = () => {
    if (!isOwner) {
      toast.error("فقط مالك الغرفة يمكنه تحميل فيديو");
      return;
    }

    const extractedId = extractVideoId(searchQuery);
    if (!extractedId) {
      toast.error("رابط YouTube غير صحيح");
      return;
    }

    playerRef.current?.loadVideoById(extractedId);
    setVideoId(extractedId);
    socket?.emit("video-load", {
      roomId,
      type: "youtube",
      videoId: extractedId,
    });
    toast.success("تم تحميل الفيديو");
  };

  const handlePlayPause = () => {
    if (!isOwner) {
      toast.error("فقط مالك الغرفة يمكنه التحكم");
      return;
    }

    const time = playerRef.current?.getCurrentTime() || 0;
    if (isPlaying) {
      playerRef.current?.pauseVideo();
      socket?.emit("video-pause", { roomId, currentTime: time });
    } else {
      playerRef.current?.playVideo();
      socket?.emit("video-play", { roomId, currentTime: time });
    }
  };

  const handleSeek = (seconds: number) => {
    if (!isOwner) {
      toast.error("فقط مالك الغرفة يمكنه التحكم");
      return;
    }

    const newTime = Math.max(0, (playerRef.current?.getCurrentTime() || 0) + seconds);
    playerRef.current?.seekTo(newTime, true);
    socket?.emit("video-seek", { roomId, currentTime: newTime });
  };

  return (
    <div className="space-y-4">
      {/* Search Bar */}
      {isOwner && (
        <div className="flex gap-2">
          <div className="flex-1">
            <Label htmlFor="youtube-search" className="sr-only">
              رابط YouTube أو معرف الفيديو
            </Label>
            <Input
              id="youtube-search"
              placeholder="أدخل رابط YouTube أو معرف الفيديو"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleLoadVideo()}
            />
          </div>
          <Button onClick={handleLoadVideo} className="flex items-center gap-2">
            <Search className="w-4 h-4" />
            تحميل
          </Button>
        </div>
      )}

      {/* Video Player */}
      <div className="aspect-video bg-black rounded-lg overflow-hidden">
        <div id="youtube-player" className="w-full h-full"></div>
      </div>

      {/* Controls */}
      <div className="flex items-center justify-center gap-2">
        <Button
          variant="outline"
          size="icon"
          onClick={() => handleSeek(-10)}
          disabled={!isOwner || !videoId}
        >
          <SkipBack className="w-4 h-4" />
        </Button>

        <Button
          size="icon"
          onClick={handlePlayPause}
          disabled={!isOwner || !videoId}
          className="w-12 h-12"
        >
          {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5" />}
        </Button>

        <Button
          variant="outline"
          size="icon"
          onClick={() => handleSeek(10)}
          disabled={!isOwner || !videoId}
        >
          <SkipForward className="w-4 h-4" />
        </Button>
      </div>

      {!isOwner && (
        <p className="text-sm text-center text-gray-500">
          فقط مالك الغرفة يمكنه التحكم في الفيديو
        </p>
      )}
    </div>
  );
}
