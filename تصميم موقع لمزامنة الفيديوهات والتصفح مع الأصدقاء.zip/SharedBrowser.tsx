import { useEffect, useRef, useState } from "react";
import { Socket } from "socket.io-client";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { ArrowLeft, ArrowRight, RotateCw, Home, Search } from "lucide-react";
import { toast } from "sonner";

interface SharedBrowserProps {
  socket: Socket | null;
  roomId: string;
  isOwner: boolean;
}

export default function SharedBrowser({ socket, roomId, isOwner }: SharedBrowserProps) {
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const [currentUrl, setCurrentUrl] = useState("https://www.google.com");
  const [inputUrl, setInputUrl] = useState("https://www.google.com");
  const [canGoBack, setCanGoBack] = useState(false);
  const [canGoForward, setCanGoForward] = useState(false);
  const [history, setHistory] = useState<string[]>(["https://www.google.com"]);
  const [historyIndex, setHistoryIndex] = useState(0);
  const isSyncing = useRef(false);

  // Socket event listeners
  useEffect(() => {
    if (!socket) return;

    socket.on("browser-navigate", ({ url }: { url: string }) => {
      if (url && url !== currentUrl) {
        isSyncing.current = true;
        navigateToUrl(url);
        setTimeout(() => {
          isSyncing.current = false;
        }, 500);
      }
    });

    socket.on("browser-state", (state: any) => {
      if (state.url) {
        isSyncing.current = true;
        navigateToUrl(state.url);
        setTimeout(() => {
          isSyncing.current = false;
        }, 500);
      }
    });

    return () => {
      socket.off("browser-navigate");
      socket.off("browser-state");
    };
  }, [socket, currentUrl]);

  const navigateToUrl = (url: string) => {
    let finalUrl = url;

    // Add https:// if no protocol
    if (!url.startsWith("http://") && !url.startsWith("https://")) {
      // Check if it looks like a domain
      if (url.includes(".") && !url.includes(" ")) {
        finalUrl = "https://" + url;
      } else {
        // Treat as search query
        finalUrl = `https://www.google.com/search?q=${encodeURIComponent(url)}`;
      }
    }

    setCurrentUrl(finalUrl);
    setInputUrl(finalUrl);

    // Update history
    const newHistory = history.slice(0, historyIndex + 1);
    newHistory.push(finalUrl);
    setHistory(newHistory);
    setHistoryIndex(newHistory.length - 1);
    setCanGoBack(newHistory.length > 1);
    setCanGoForward(false);
  };

  const handleNavigate = () => {
    if (!isOwner) {
      toast.error("فقط مالك الغرفة يمكنه التحكم في المتصفح");
      return;
    }

    if (!inputUrl.trim()) {
      toast.error("يرجى إدخال عنوان URL");
      return;
    }

    navigateToUrl(inputUrl);

    if (!isSyncing.current) {
      socket?.emit("browser-navigate", { roomId, url: currentUrl });
    }
  };

  const handleGoBack = () => {
    if (!isOwner) {
      toast.error("فقط مالك الغرفة يمكنه التحكم");
      return;
    }

    if (historyIndex > 0) {
      const newIndex = historyIndex - 1;
      const url = history[newIndex];
      setCurrentUrl(url);
      setInputUrl(url);
      setHistoryIndex(newIndex);
      setCanGoBack(newIndex > 0);
      setCanGoForward(true);

      socket?.emit("browser-navigate", { roomId, url });
    }
  };

  const handleGoForward = () => {
    if (!isOwner) {
      toast.error("فقط مالك الغرفة يمكنه التحكم");
      return;
    }

    if (historyIndex < history.length - 1) {
      const newIndex = historyIndex + 1;
      const url = history[newIndex];
      setCurrentUrl(url);
      setInputUrl(url);
      setHistoryIndex(newIndex);
      setCanGoBack(true);
      setCanGoForward(newIndex < history.length - 1);

      socket?.emit("browser-navigate", { roomId, url });
    }
  };

  const handleRefresh = () => {
    if (!isOwner) {
      toast.error("فقط مالك الغرفة يمكنه التحكم");
      return;
    }

    if (iframeRef.current) {
      iframeRef.current.src = currentUrl;
    }
  };

  const handleHome = () => {
    if (!isOwner) {
      toast.error("فقط مالك الغرفة يمكنه التحكم");
      return;
    }

    const homeUrl = "https://www.google.com";
    navigateToUrl(homeUrl);
    socket?.emit("browser-navigate", { roomId, url: homeUrl });
  };

  return (
    <div className="space-y-4">
      {/* Browser Controls */}
      <div className="flex gap-2">
        <div className="flex gap-1">
          <Button
            variant="outline"
            size="icon"
            onClick={handleGoBack}
            disabled={!isOwner || !canGoBack}
          >
            <ArrowRight className="w-4 h-4" />
          </Button>
          <Button
            variant="outline"
            size="icon"
            onClick={handleGoForward}
            disabled={!isOwner || !canGoForward}
          >
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <Button
            variant="outline"
            size="icon"
            onClick={handleRefresh}
            disabled={!isOwner}
          >
            <RotateCw className="w-4 h-4" />
          </Button>
          <Button
            variant="outline"
            size="icon"
            onClick={handleHome}
            disabled={!isOwner}
          >
            <Home className="w-4 h-4" />
          </Button>
        </div>

        <div className="flex-1 flex gap-2">
          <Input
            value={inputUrl}
            onChange={(e) => setInputUrl(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleNavigate()}
            placeholder="أدخل عنوان URL أو ابحث..."
            disabled={!isOwner}
            className="flex-1"
          />
          <Button onClick={handleNavigate} disabled={!isOwner} className="flex items-center gap-2">
            <Search className="w-4 h-4" />
            انتقال
          </Button>
        </div>
      </div>

      {/* Browser View */}
      <div className="aspect-video bg-white rounded-lg overflow-hidden border-2 border-gray-200 relative">
        <iframe
          ref={iframeRef}
          src={currentUrl}
          className="w-full h-full"
          sandbox="allow-same-origin allow-scripts allow-popups allow-forms"
          title="Shared Browser"
        />
        
        {/* Overlay for non-owners to prevent interaction */}
        {!isOwner && (
          <div className="absolute inset-0 bg-transparent cursor-not-allowed" />
        )}
      </div>

      {/* Info */}
      <div className="text-sm text-gray-500 text-center">
        {isOwner ? (
          <p>أنت تتحكم في المتصفح. جميع المشاركين يرون ما تتصفحه.</p>
        ) : (
          <p>فقط مالك الغرفة يمكنه التحكم في المتصفح.</p>
        )}
      </div>

      {/* Warning */}
      <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3">
        <p className="text-sm text-yellow-800">
          <strong>ملاحظة:</strong> بعض المواقع قد تمنع التضمين في iframe لأسباب أمنية. 
          إذا لم يظهر الموقع، جرب موقعاً آخر.
        </p>
      </div>
    </div>
  );
}
