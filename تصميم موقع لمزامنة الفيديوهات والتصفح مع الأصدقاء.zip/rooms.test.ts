import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

// Mock user context
function createMockContext(userId: number = 1): TrpcContext {
  return {
    user: {
      id: userId,
      openId: `user-${userId}`,
      email: `user${userId}@example.com`,
      name: `Test User ${userId}`,
      loginMethod: "test",
      role: "user",
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    },
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: () => {},
    } as TrpcContext["res"],
  };
}

describe("Rooms API", () => {
  let roomUuid: string;
  const caller = appRouter.createCaller(createMockContext(1));

  it("should create a new room", async () => {
    const result = await caller.rooms.create({
      name: "Test Room",
    });

    expect(result).toBeDefined();
    expect(result?.name).toBe("Test Room");
    expect(result?.uuid).toBeDefined();
    expect(result?.ownerId).toBe(1);

    roomUuid = result?.uuid || "";
  });

  it("should get room by UUID", async () => {
    if (!roomUuid) {
      throw new Error("Room UUID not set");
    }

    const result = await caller.rooms.getByUuid({
      uuid: roomUuid,
    });

    expect(result).toBeDefined();
    expect(result?.name).toBe("Test Room");
    expect(result?.uuid).toBe(roomUuid);
  });

  it("should get room by ID", async () => {
    if (!roomUuid) {
      throw new Error("Room UUID not set");
    }

    const room = await caller.rooms.getByUuid({ uuid: roomUuid });
    if (!room) throw new Error("Room not found");

    const result = await caller.rooms.getById({
      id: room.id,
    });

    expect(result).toBeDefined();
    expect(result?.id).toBe(room.id);
  });

  it("should list active rooms", async () => {
    const result = await caller.rooms.list();

    expect(Array.isArray(result)).toBe(true);
    expect(result.length).toBeGreaterThan(0);
  });
});

describe("Messages API", () => {
  let roomId: number;
  const caller = appRouter.createCaller(createMockContext(1));

  beforeAll(async () => {
    const room = await caller.rooms.create({
      name: "Message Test Room",
    });
    if (!room) throw new Error("Failed to create room");
    roomId = room.id;
  });

  it("should get messages by room ID", async () => {
    const result = await caller.messages.getByRoomId({
      roomId,
      limit: 10,
    });

    expect(Array.isArray(result)).toBe(true);
  });

  it("should handle empty message list", async () => {
    const result = await caller.messages.getByRoomId({
      roomId,
      limit: 10,
    });

    expect(result.length).toBe(0);
  });
});

describe("Auth API", () => {
  const caller = appRouter.createCaller(createMockContext(1));

  it("should get current user info", async () => {
    const result = await caller.auth.me();

    expect(result).toBeDefined();
    expect(result?.id).toBe(1);
    expect(result?.name).toBe("Test User 1");
  });

  it("should handle logout", async () => {
    const result = await caller.auth.logout();

    expect(result).toBeDefined();
    expect(result.success).toBe(true);
  });
});

describe("Videos API", () => {
  let roomId: number;
  const caller = appRouter.createCaller(createMockContext(1));

  beforeAll(async () => {
    const room = await caller.rooms.create({
      name: "Video Test Room",
    });
    if (!room) throw new Error("Failed to create room");
    roomId = room.id;
  });

  it("should get videos by room ID", async () => {
    const result = await caller.videos.getByRoomId({
      roomId,
    });

    expect(Array.isArray(result)).toBe(true);
  });

  it("should handle empty video list", async () => {
    const result = await caller.videos.getByRoomId({
      roomId,
    });

    expect(result.length).toBe(0);
  });
});
