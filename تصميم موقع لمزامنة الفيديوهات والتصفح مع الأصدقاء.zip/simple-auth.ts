import { SignJWT, jwtVerify } from "jose";
import type { Request, Response } from "express";
import type { User } from "../../drizzle/schema";
import { ENV } from "./env";
import { COOKIE_NAME } from "@shared/const";
import { getUserById } from "../auth";

const JWT_SECRET = new TextEncoder().encode(ENV.jwtSecret || "your-secret-key");

export type SessionPayload = {
  userId: number;
  username: string;
};

/**
 * Create a session token
 */
export async function createSessionToken(userId: number, username: string): Promise<string> {
  const token = await new SignJWT({ userId, username })
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime("7d")
    .sign(JWT_SECRET);

  return token;
}

/**
 * Verify a session token
 */
export async function verifySessionToken(token: string): Promise<SessionPayload | null> {
  try {
    const verified = await jwtVerify(token, JWT_SECRET);
    return verified.payload as SessionPayload;
  } catch (error) {
    return null;
  }
}

/**
 * Set session cookie
 */
export function setSessionCookie(res: Response, token: string): void {
  const isProduction = process.env.NODE_ENV === "production";
  const protocol = process.env.PROTOCOL || "https";

  res.cookie(COOKIE_NAME, token, {
    httpOnly: true,
    secure: protocol === "https",
    sameSite: "lax",
    maxAge: 7 * 24 * 60 * 60 * 1000, // 7 days
    path: "/",
  });
}

/**
 * Get user from request
 */
export async function getUserFromRequest(req: Request): Promise<User | null> {
  try {
    const cookies = parseCookies(req.headers.cookie);
    const sessionCookie = cookies.get(COOKIE_NAME);

    if (!sessionCookie) {
      return null;
    }

    const session = await verifySessionToken(sessionCookie);
    if (!session) {
      return null;
    }

    const user = await getUserById(session.userId);
    return user || null;
  } catch (error) {
    console.error("[Auth] Error getting user from request:", error);
    return null;
  }
}

/**
 * Parse cookies from header
 */
function parseCookies(cookieHeader?: string): Map<string, string> {
  const cookies = new Map<string, string>();

  if (!cookieHeader) {
    return cookies;
  }

  const parts = cookieHeader.split(/;\s*/);
  for (const part of parts) {
    const [key, value] = part.split("=");
    if (key && value) {
      cookies.set(key.trim(), decodeURIComponent(value.trim()));
    }
  }

  return cookies;
}
