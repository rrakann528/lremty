import { COOKIE_NAME } from "@shared/const";
import type { Express, Request, Response } from "express";
import { registerUser, loginUser } from "../auth";
import { createSessionToken, setSessionCookie } from "./simple-auth";
import { getSessionCookieOptions } from "./cookies";

export function registerAuthRoutes(app: Express) {
  /**
   * Register route
   */
  app.post("/api/auth/register", async (req: Request, res: Response) => {
    try {
      const { username, email, password, name } = req.body;

      if (!username || !email || !password) {
        res.status(400).json({ error: "username, email, and password are required" });
        return;
      }

      const user = await registerUser(username, email, password, name);

      // Create session token
      const token = await createSessionToken(user.id, user.username);
      setSessionCookie(res, token);

      res.json({
        success: true,
        user: {
          id: user.id,
          username: user.username,
          email: user.email,
          name: user.name,
        },
      });
    } catch (error: any) {
      console.error("[Auth] Register failed:", error);
      res.status(400).json({ error: error.message || "Registration failed" });
    }
  });

  /**
   * Login route
   */
  app.post("/api/auth/login", async (req: Request, res: Response) => {
    try {
      const { username, password } = req.body;

      if (!username || !password) {
        res.status(400).json({ error: "username and password are required" });
        return;
      }

      const user = await loginUser(username, password);

      // Create session token
      const token = await createSessionToken(user.id, user.username);
      setSessionCookie(res, token);

      res.json({
        success: true,
        user: {
          id: user.id,
          username: user.username,
          email: user.email,
          name: user.name,
        },
      });
    } catch (error: any) {
      console.error("[Auth] Login failed:", error);
      res.status(401).json({ error: error.message || "Login failed" });
    }
  });

  /**
   * Logout route
   */
  app.post("/api/auth/logout", (req: Request, res: Response) => {
    const cookieOptions = getSessionCookieOptions(req);
    res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
    res.json({ success: true });
  });
}
