import { Server as SocketIOServer } from 'socket.io';
import type { Server as HTTPServer } from 'http';
import { createMessage } from './db';

interface RoomUser {
  id: string;
  userId: number;
  userName: string;
}

interface VideoState {
  type: 'youtube' | 'local';
  videoId?: string; // for YouTube
  videoUrl?: string; // for local files
  currentTime: number;
  isPlaying: boolean;
  playbackRate: number;
}

interface BrowserState {
  url: string;
  scrollX: number;
  scrollY: number;
}

// Store active rooms and their users
const roomUsers: Map<string, Map<string, RoomUser>> = new Map();
const roomVideoStates: Map<string, VideoState> = new Map();
const roomBrowserStates: Map<string, BrowserState> = new Map();

export function setupSocketIO(httpServer: HTTPServer) {
  const io = new SocketIOServer(httpServer, {
    cors: {
      origin: "*",
      methods: ["GET", "POST"]
    },
    path: '/api/socket.io'
  });

  io.on('connection', (socket) => {
    console.log('[Socket.IO] User connected:', socket.id);

    // Join room
    socket.on('join-room', ({ roomId, userId, userName }: { roomId: string; userId: number; userName: string }) => {
      console.log(`[Socket.IO] User ${userName} joining room ${roomId}`);
      
      socket.join(roomId);
      
      // Add user to room
      if (!roomUsers.has(roomId)) {
        roomUsers.set(roomId, new Map());
      }
      roomUsers.get(roomId)!.set(socket.id, { id: socket.id, userId, userName });
      
      // Send current room state to the new user
      const videoState = roomVideoStates.get(roomId);
      if (videoState) {
        socket.emit('video-state', videoState);
      }
      
      const browserState = roomBrowserStates.get(roomId);
      if (browserState) {
        socket.emit('browser-state', browserState);
      }
      
      // Notify others in the room
      const users = Array.from(roomUsers.get(roomId)!.values());
      io.to(roomId).emit('room-users', users);
      
      socket.emit('join-success', { roomId, users });
    });

    // Leave room
    socket.on('leave-room', ({ roomId }: { roomId: string }) => {
      handleLeaveRoom(socket.id, roomId);
    });

    // ============= Text Chat Events =============
    
    socket.on('send-message', async ({ roomId, roomIdNum, userId, userName, content }: { 
      roomId: string; 
      roomIdNum: number;
      userId: number; 
      userName: string; 
      content: string 
    }) => {
      try {
        // Save message to database
        await createMessage({
          roomId: roomIdNum,
          userId,
          userName,
          content
        });
        
        // Broadcast to all users in the room
        io.to(roomId).emit('new-message', {
          userId,
          userName,
          content,
          createdAt: new Date()
        });
      } catch (error) {
        console.error('[Socket.IO] Error sending message:', error);
      }
    });

    // ============= Video Sync Events =============
    
    socket.on('video-play', ({ roomId, currentTime }: { roomId: string; currentTime: number }) => {
      const state = roomVideoStates.get(roomId) || { type: 'youtube', currentTime: 0, isPlaying: false, playbackRate: 1 };
      state.currentTime = currentTime;
      state.isPlaying = true;
      roomVideoStates.set(roomId, state);
      
      socket.to(roomId).emit('video-play', { currentTime });
    });

    socket.on('video-pause', ({ roomId, currentTime }: { roomId: string; currentTime: number }) => {
      const state = roomVideoStates.get(roomId) || { type: 'youtube', currentTime: 0, isPlaying: false, playbackRate: 1 };
      state.currentTime = currentTime;
      state.isPlaying = false;
      roomVideoStates.set(roomId, state);
      
      socket.to(roomId).emit('video-pause', { currentTime });
    });

    socket.on('video-seek', ({ roomId, currentTime }: { roomId: string; currentTime: number }) => {
      const state = roomVideoStates.get(roomId) || { type: 'youtube', currentTime: 0, isPlaying: false, playbackRate: 1 };
      state.currentTime = currentTime;
      roomVideoStates.set(roomId, state);
      
      socket.to(roomId).emit('video-seek', { currentTime });
    });

    socket.on('video-load', ({ roomId, type, videoId, videoUrl }: { 
      roomId: string; 
      type: 'youtube' | 'local';
      videoId?: string;
      videoUrl?: string;
    }) => {
      const state: VideoState = {
        type,
        videoId,
        videoUrl,
        currentTime: 0,
        isPlaying: false,
        playbackRate: 1
      };
      roomVideoStates.set(roomId, state);
      
      socket.to(roomId).emit('video-load', { type, videoId, videoUrl });
    });

    socket.on('video-rate-change', ({ roomId, playbackRate }: { roomId: string; playbackRate: number }) => {
      const state = roomVideoStates.get(roomId);
      if (state) {
        state.playbackRate = playbackRate;
        roomVideoStates.set(roomId, state);
      }
      
      socket.to(roomId).emit('video-rate-change', { playbackRate });
    });

    // ============= Browser Sync Events =============
    
    socket.on('browser-navigate', ({ roomId, url }: { roomId: string; url: string }) => {
      const state = roomBrowserStates.get(roomId) || { url: '', scrollX: 0, scrollY: 0 };
      state.url = url;
      roomBrowserStates.set(roomId, state);
      
      socket.to(roomId).emit('browser-navigate', { url });
    });

    socket.on('browser-scroll', ({ roomId, scrollX, scrollY }: { roomId: string; scrollX: number; scrollY: number }) => {
      const state = roomBrowserStates.get(roomId) || { url: '', scrollX: 0, scrollY: 0 };
      state.scrollX = scrollX;
      state.scrollY = scrollY;
      roomBrowserStates.set(roomId, state);
      
      socket.to(roomId).emit('browser-scroll', { scrollX, scrollY });
    });

    socket.on('browser-click', ({ roomId, x, y }: { roomId: string; x: number; y: number }) => {
      socket.to(roomId).emit('browser-click', { x, y });
    });

    socket.on('browser-input', ({ roomId, selector, value }: { roomId: string; selector: string; value: string }) => {
      socket.to(roomId).emit('browser-input', { selector, value });
    });

    // ============= Voice Chat Events =============
    
    socket.on('voice-signal', ({ roomId, signal, to }: { roomId: string; signal: any; to: string }) => {
      io.to(to).emit('voice-signal', { signal, from: socket.id });
    });

    socket.on('voice-join', ({ roomId }: { roomId: string }) => {
      const users = roomUsers.get(roomId);
      if (users) {
        const otherUsers = Array.from(users.values()).filter(u => u.id !== socket.id);
        socket.emit('voice-users', otherUsers.map(u => u.id));
      }
    });

    // ============= Disconnect =============
    
    socket.on('disconnect', () => {
      console.log('[Socket.IO] User disconnected:', socket.id);
      
      // Remove user from all rooms
      roomUsers.forEach((users, roomId) => {
        if (users.has(socket.id)) {
          handleLeaveRoom(socket.id, roomId);
        }
      });
    });
  });

  function handleLeaveRoom(socketId: string, roomId: string) {
    const users = roomUsers.get(roomId);
    if (users) {
      users.delete(socketId);
      
      // Notify others
      const remainingUsers = Array.from(users.values());
      io.to(roomId).emit('room-users', remainingUsers);
      
      // Clean up empty rooms
      if (users.size === 0) {
        roomUsers.delete(roomId);
        roomVideoStates.delete(roomId);
        roomBrowserStates.delete(roomId);
      }
    }
  }

  return io;
}
