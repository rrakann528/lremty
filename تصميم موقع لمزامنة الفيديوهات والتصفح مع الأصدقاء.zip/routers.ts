import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { v4 as uuidv4 } from "uuid";
import { 
  createRoom, 
  getRoomByUuid, 
  getRoomById,
  getActiveRooms,
  getMessagesByRoomId,
  createVideo,
  getVideosByRoomId
} from "./db";
import { storagePut } from "./storage";
import { startNekoInstance, stopNekoInstance, getNekoInstance, isDockerAvailable } from "./neko";

export const appRouter = router({
  system: systemRouter,
  
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  rooms: router({
    create: protectedProcedure
      .input(z.object({
        name: z.string().min(1).max(255),
      }))
      .mutation(async ({ ctx, input }) => {
        const uuid = uuidv4();
        await createRoom({
          uuid,
          name: input.name,
          ownerId: ctx.user.id,
          isActive: true,
        });
        
        const room = await getRoomByUuid(uuid);
        return room;
      }),
    
    getByUuid: publicProcedure
      .input(z.object({
        uuid: z.string(),
      }))
      .query(async ({ input }) => {
        return await getRoomByUuid(input.uuid);
      }),
    
    getById: publicProcedure
      .input(z.object({
        id: z.number(),
      }))
      .query(async ({ input }) => {
        return await getRoomById(input.id);
      }),
    
    list: publicProcedure.query(async () => {
      return await getActiveRooms();
    }),
  }),

  messages: router({
    getByRoomId: publicProcedure
      .input(z.object({
        roomId: z.number(),
        limit: z.number().optional(),
      }))
      .query(async ({ input }) => {
        return await getMessagesByRoomId(input.roomId, input.limit);
      }),
  }),

  videos: router({
    upload: protectedProcedure
      .input(z.object({
        roomId: z.number(),
        fileName: z.string(),
        fileData: z.string(), // base64 encoded
        mimeType: z.string(),
      }))
      .mutation(async ({ ctx, input }) => {
        // Decode base64
        const buffer = Buffer.from(input.fileData, 'base64');
        const fileSize = buffer.length;
        
        // Generate unique file key
        const timestamp = Date.now();
        const randomSuffix = Math.random().toString(36).substring(7);
        const fileKey = `videos/${ctx.user.id}/${timestamp}-${randomSuffix}-${input.fileName}`;
        
        // Upload to S3
        const { url } = await storagePut(fileKey, buffer, input.mimeType);
        
        // Save to database
        await createVideo({
          roomId: input.roomId,
          userId: ctx.user.id,
          fileName: input.fileName,
          fileKey,
          fileUrl: url,
          mimeType: input.mimeType,
          fileSize,
        });
        
        return { url, fileKey };
      }),
    
    getByRoomId: publicProcedure
      .input(z.object({
        roomId: z.number(),
      }))
      .query(async ({ input }) => {
        return await getVideosByRoomId(input.roomId);
      }),
  }),

  browser: router({
    checkDocker: publicProcedure.query(() => {
      return { available: isDockerAvailable() };
    }),
    
    startNeko: protectedProcedure
      .input(z.object({
        roomId: z.string(),
      }))
      .mutation(async ({ input }) => {
        if (!isDockerAvailable()) {
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: "Docker غير متوفر على الخادم. يرجى التأكد من تثبيت Docker.",
          });
        }
        
        try {
          const instance = await startNekoInstance(input.roomId);
          if (!instance) {
            throw new TRPCError({
              code: "INTERNAL_SERVER_ERROR",
              message: "فشل في بدء متصفح Neko. تحقق من سجلات الخادم.",
            });
          }
          return {
            port: instance.port,
            wsPort: instance.wsPort,
            password: instance.password,
            url: instance.url,
          };
        } catch (error: any) {
          console.error("[Browser] Error starting Neko:", error);
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: error.message || "فشل في بدء متصفح Neko",
          });
        }
      }),
    
    stopNeko: protectedProcedure
      .input(z.object({
        roomId: z.string(),
      }))
      .mutation(async ({ input }) => {
        const success = await stopNekoInstance(input.roomId);
        return { success };
      }),
    
    getNekoInfo: publicProcedure
      .input(z.object({
        roomId: z.string(),
      }))
      .query(({ input }) => {
        const instance = getNekoInstance(input.roomId);
        if (!instance) {
          return null;
        }
        return {
          port: instance.port,
          wsPort: instance.wsPort,
          password: instance.password,
          url: instance.url,
        };
      }),
  }),
});

export type AppRouter = typeof appRouter;
