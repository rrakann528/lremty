import { eq, desc } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, rooms, InsertRoom, messages, InsertMessage, videos, InsertVideo } from "../drizzle/schema";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ============= Room Functions =============

export async function createRoom(room: InsertRoom) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(rooms).values(room);
  return result;
}

export async function getRoomByUuid(uuid: string) {
  const db = await getDb();
  if (!db) return undefined;
  
  const result = await db.select().from(rooms).where(eq(rooms.uuid, uuid)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getRoomById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  
  const result = await db.select().from(rooms).where(eq(rooms.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getActiveRooms() {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select().from(rooms).where(eq(rooms.isActive, true)).orderBy(desc(rooms.createdAt));
}

// ============= Message Functions =============

export async function createMessage(message: InsertMessage) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(messages).values(message);
  return result;
}

export async function getMessagesByRoomId(roomId: number, limit: number = 100) {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select().from(messages).where(eq(messages.roomId, roomId)).orderBy(desc(messages.createdAt)).limit(limit);
}

// ============= Video Functions =============

export async function createVideo(video: InsertVideo) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(videos).values(video);
  return result;
}

export async function getVideosByRoomId(roomId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select().from(videos).where(eq(videos.roomId, roomId)).orderBy(desc(videos.createdAt));
}
