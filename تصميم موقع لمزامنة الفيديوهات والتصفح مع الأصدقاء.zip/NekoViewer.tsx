import { useEffect, useRef, useState } from "react";
import { Socket } from "socket.io-client";
import { Button } from "./ui/button";
import { Card } from "./ui/card";
import { Play, Square, Loader, AlertCircle } from "lucide-react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";

interface NekoViewerProps {
  socket: Socket | null;
  roomId: string;
  isOwner: boolean;
}

export default function NekoViewer({ socket, roomId, isOwner }: NekoViewerProps) {
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const [isStarting, setIsStarting] = useState(false);
  const [isRunning, setIsRunning] = useState(false);
  const [nekoUrl, setNekoUrl] = useState<string>("");
  const [dockerAvailable, setDockerAvailable] = useState<boolean | null>(null);
  const [error, setError] = useState<string | null>(null);

  const startNekoMutation = trpc.browser.startNeko.useMutation();
  const stopNekoMutation = trpc.browser.stopNeko.useMutation();
  const getNekoInfoQuery = trpc.browser.getNekoInfo.useQuery(
    { roomId },
    { enabled: false, refetchInterval: 5000 }
  );

  // Check if Neko is already running
  useEffect(() => {
    const checkNeko = async () => {
      try {
        const result = await getNekoInfoQuery.refetch();
        if (result.data) {
          setNekoUrl(result.data.url);
          setIsRunning(true);
          setDockerAvailable(true);
        }
      } catch (error) {
        console.log("Neko not running");
        setDockerAvailable(false);
      }
    };

    checkNeko();
  }, []);

  const handleStartNeko = async () => {
    if (!isOwner) {
      toast.error("فقط مالك الغرفة يمكنه بدء المتصفح");
      return;
    }

    setIsStarting(true);
    setError(null);
    toast.info("جاري بدء متصفح Neko...");

    try {
      const result = await startNekoMutation.mutateAsync({ roomId });
      setNekoUrl(result.url);
      setIsRunning(true);
      setDockerAvailable(true);
      toast.success("تم بدء المتصفح بنجاح");

      // Notify other users
      socket?.emit("browser-started", { roomId });
    } catch (error: any) {
      const errorMsg = error.message || "فشل بدء المتصفح";
      setError(errorMsg);
      
      if (errorMsg.includes("Docker")) {
        setDockerAvailable(false);
        toast.error("Docker غير متوفر على الخادم");
      } else {
        toast.error("فشل بدء المتصفح: " + errorMsg);
      }
      console.error(error);
    } finally {
      setIsStarting(false);
    }
  };

  const handleStopNeko = async () => {
    if (!isOwner) {
      toast.error("فقط مالك الغرفة يمكنه إيقاف المتصفح");
      return;
    }

    try {
      await stopNekoMutation.mutateAsync({ roomId });
      setNekoUrl("");
      setIsRunning(false);
      setError(null);
      toast.success("تم إيقاف المتصفح");

      // Notify other users
      socket?.emit("browser-stopped", { roomId });
    } catch (error: any) {
      toast.error("فشل إيقاف المتصفح: " + error.message);
    }
  };

  // Listen for browser events
  useEffect(() => {
    if (!socket) return;

    socket.on("browser-started", ({ roomId: eventRoomId }: { roomId: string }) => {
      if (eventRoomId === roomId && !isRunning) {
        setIsRunning(true);
        toast.info("تم بدء المتصفح من قبل مالك الغرفة");
      }
    });

    socket.on("browser-stopped", ({ roomId: eventRoomId }: { roomId: string }) => {
      if (eventRoomId === roomId && isRunning) {
        setIsRunning(false);
        setNekoUrl("");
        toast.info("تم إيقاف المتصفح");
      }
    });

    return () => {
      socket.off("browser-started");
      socket.off("browser-stopped");
    };
  }, [socket, roomId, isRunning]);

  return (
    <div className="space-y-4">
      {/* Controls */}
      <div className="flex gap-2">
        {!isRunning ? (
          <Button
            onClick={handleStartNeko}
            disabled={isStarting || !isOwner || dockerAvailable === false}
            className="flex items-center gap-2 flex-1"
          >
            {isStarting ? (
              <>
                <Loader className="w-4 h-4 animate-spin" />
                جاري البدء...
              </>
            ) : (
              <>
                <Play className="w-4 h-4" />
                بدء المتصفح
              </>
            )}
          </Button>
        ) : (
          <Button
            onClick={handleStopNeko}
            disabled={!isOwner}
            variant="destructive"
            className="flex items-center gap-2 flex-1"
          >
            <Square className="w-4 h-4" />
            إيقاف المتصفح
          </Button>
        )}
      </div>

      {/* Neko Viewer */}
      {isRunning && nekoUrl ? (
        <div className="aspect-video bg-black rounded-lg overflow-hidden border-2 border-gray-200">
          <iframe
            ref={iframeRef}
            src={nekoUrl}
            className="w-full h-full"
            title="Neko Browser"
            allow="microphone; camera"
          />
        </div>
      ) : (
        <Card className="aspect-video flex items-center justify-center bg-gray-100">
          <div className="text-center">
            <div className="text-6xl mb-4">🌐</div>
            <p className="text-gray-600 font-medium">المتصفح الافتراضي</p>
            {isOwner ? (
              <p className="text-gray-500 text-sm mt-2">
                انقر على "بدء المتصفح" للبدء
              </p>
            ) : (
              <p className="text-gray-500 text-sm mt-2">
                في انتظار مالك الغرفة لبدء المتصفح
              </p>
            )}
          </div>
        </Card>
      )}

      {/* Error Message */}
      {error && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-3 flex gap-2">
          <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
          <div>
            <p className="text-sm text-red-800 font-medium">خطأ</p>
            <p className="text-sm text-red-700">{error}</p>
          </div>
        </div>
      )}

      {/* Docker Status */}
      {dockerAvailable === false ? (
        <div className="bg-red-50 border border-red-200 rounded-lg p-3 flex gap-2">
          <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
          <div>
            <p className="text-sm text-red-800 font-medium">⚠️ Docker غير متوفر</p>
            <p className="text-sm text-red-700">
              {isOwner 
                ? "يرجى التأكد من تثبيت Docker على الخادم لاستخدام المتصفح الافتراضي."
                : "المتصفح الافتراضي غير متاح حالياً."}
            </p>
          </div>
        </div>
      ) : (
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
          <p className="text-sm text-blue-800">
            <strong>ملاحظة:</strong> المتصفح الافتراضي يعمل على Docker. 
            {isOwner && " تأكد من تثبيت Docker على الخادم."}
          </p>
        </div>
      )}
    </div>
  );
}
