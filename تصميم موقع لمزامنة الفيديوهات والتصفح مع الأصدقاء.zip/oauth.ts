import type { Express } from "express";

// OAuth routes are deprecated - use auth-routes instead
export function registerOAuthRoutes(app: Express) {
  // This function is no longer used
}
